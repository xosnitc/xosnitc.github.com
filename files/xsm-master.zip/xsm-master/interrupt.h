#ifndef INTERRUPT_H
#define INTERRUPT_H

#define INT_START_PAGE		8
#define NUM_INT				8
#define EXCEP_HANDLER		7
#endif
