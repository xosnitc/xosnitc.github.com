xfs-interface
=============

Interface for accessing XFS filesystem through UNIX. 