#ifndef DEBUG_H
#define DEBUG_H
#include "data.h"
#include "memory_constants.h"
#include "interrupt.h"
#include <stdio.h>
void printRegisters();
#endif
