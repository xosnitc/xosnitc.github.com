#define DISK_NAME 	"disk"
#define BOOT_BLOCK	0