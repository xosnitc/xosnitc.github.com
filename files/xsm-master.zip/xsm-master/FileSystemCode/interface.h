#ifndef INTERFACE_H
#define INTERFACE_H
#include "fileSystem.h"
#include "createDisk.h"
#define DO_NOT_FORMAT 0
#define FORMAT 1


void menu();
#endif